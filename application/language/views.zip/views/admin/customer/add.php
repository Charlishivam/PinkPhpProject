<div class="content-wrapper">
   <!-- Main content -->
   <section class="content">
      <div class="card card-default">
         <div class="card-header">
            <div class="d-inline-block">
               <h3 class="card-title"> <i class="fa fa-plus"></i>
                  Add New Customer  
               </h3>
            </div>
            <div class="d-inline-block float-right">
               <a href="<?= base_url('admin/customer'); ?>" class="btn btn-success"><i class="fa fa-list"></i> Customer List</a>
            </div>
         </div>
         <div class="card-body">
            <!-- For Messages -->
            <?php $this->load->view('admin/includes/_messages.php') ?>
            <?php echo form_open_multipart(base_url('admin/customer/add'), 'class="form-horizontal"');  ?> 
            <div class="row">
               <div class="col-md-6">
                   <div class="form-group">
                     <label for="title" class="col-md-6 control-label">First Name<span class="text-red" style="color:red">*</span></label>
                     <div class="col-md-12">
                        <input type="text" name="customer_first_name" required="" value="<?= set_value('customer_first_name') ?>" class="form-control" id="name" placeholder="Enter First Name" >
                     </div>
                  </div>
               </div>
               <div class="col-md-6">
                   <div class="form-group">
                     <label for="title" class="col-md-6 control-label">Last Name<span class="text-red" style="color:red">*</span></label>
                     <div class="col-md-12">
                        <input type="text" name="customer_last_name" required="" value="<?= set_value('customer_last_name') ?>" class="form-control" id="customer_last_name" placeholder="Enter First Name" >
                     </div>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-6">
                   <div class="form-group">
                     <label for="title" class="col-md-6 control-label">Mobile Number<span class="text-red" style="color:red">*</span></label>
                    
                     <div class="col-md-12">
                        <input type="number" name="customer_mobile" required="" class="form-control" value="<?= set_value('customer_mobile') ?>" id="customer_mobile" placeholder="Enter Mobile Number">
                     </div>
                  </div>
               </div>
               <div class="col-md-6">
                  <label for="title" class="col-md-6 control-label">Email<span class="text-red" style="color:red">*</span></label>
                     <div class="col-md-12">
                        <input type="email"  required="" name="customer_email" class="form-control" id="mobile" value="<?= set_value('customer_email') ?>" placeholder="Enter Email">
                     </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-6">
                   <div class="form-group">
                     <label for="title" class="col-md-6 control-label">Password<span class="text-red" style="color:red">*</span></label>
                     <div class="col-md-12">
                        <input type="password" required="" name="customer_password" class="form-control" value="<?= set_value('customer_password') ?>" id="customer_password" placeholder=" Enter Password ">
                     </div>
                  </div>
               </div>
               <div class="col-md-6">
                  <label for="title" class="col-md-6 control-label">Country</label>
                     <div class="col-md-12">
                        <input type="ad_country" required="" name="ad_country" class="form-control" id="ad_country" value="<?= set_value('ad_country') ?>" placeholder="Enter Country">
                     </div>
               </div>
            </div>

            <div class="row">
               <div class="col-md-6">
                   <div class="form-group">
                     <label for="ad_state"  class="col-md-6 control-label">State</label>
                     <div class="col-md-12">
                        <input type="text" name="ad_state" value="<?= set_value('ad_state') ?>" class="form-control" id="ad_state" placeholder=" Enter State">
                     </div>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="form-group">
                     <label for="ad_city"  class="col-md-6 control-label">City</label>
                     <div class="col-md-12">
                        <input type="text" value="<?= set_value('ad_city') ?>" name="ad_city" class="form-control" id="ad_city" placeholder=" Enter City">
                     </div>
                  </div>
               </div>
            </div>

            <div class="row">
               <div class="col-md-6">
                   <div class="form-group">
                     <label for="title" class="col-md-6 control-label">Address<span class="text-red" style="color:red">*</span></label>
                     <div class="col-md-12">
                        <input type="text" required="" value="<?= set_value('ad_fulladdress') ?>" name="ad_fulladdress" class="form-control" id="ad_fulladdress" placeholder=" Enter address ">
                     </div>
                  </div>
               </div>
               <div class="col-md-6">
                  <label for="title" class="col-md-6 control-label">Pincode<span class="text-red" style="color:red">*</span></label>
                     <div class="col-md-12">
                        <input type="text" value="<?= set_value('ad_postcode') ?>" required="" name="ad_postcode" class="form-control" id="ad_postcode" placeholder=" Enter Pincode ">
                     </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-6">
                   <div class="form-group">
                     <label for="cat_name" name="tittle" class="col-md-6 control-label">Longitude</label>
                     <div class="col-md-12">
                        <input type="text" name="ad_longitude" class="form-control" id="ad_longitude" value="<?= set_value('ad_longitude') ?>" placeholder=" Enter Longitude ">
                     </div>
                  </div>
               </div>
               <div class="col-md-6">
                  <label for="latitude" class="col-md-6 control-label">Latitude</label>
                     <div class="col-md-12">
                        <input type="text" name="ad_latitude" class="form-control" id="ad_latitude" placeholder=" Enter latitude" value="<?= set_value('ad_latitude') ?>">
                     </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-6">
                   <div class="form-group">
                     <label for="title" class="col-md-6 control-label">Customer Image<span class="text-red" style="color:red">*</span></label>
                     <div class="col-md-12">
                        <input type="file" name="customer_image" class="custom-file-input" id="imgInp">
                        <label class="custom-file-label" for="imgInp">Choose file</label>
                     </div>
                  </div>
               </div>

               <div class="col-md-6">
                   <div class="form-group">
                     <label for="title" class="col-md-6 control-label">Customer Designation <span class="text-red" style="color:red">*</span></label>
                     <div class="col-md-12">
                        <input type="text" name="customer_designation" class="form-control" id="customer_designation" placeholder=" Enter Designation" value="<?= set_value('customer_designation') ?>">
                        
                     </div>
                  </div>
               </div>
            </div>
            <div class="form-group">
              <img id="blah" src="<?= base_url('uploads/images/image-placeholder.jpg'); ?>" width="150" height="150"/>
            </div>
            
            <div class="form-group">
               <div class="col-md-12">
                  <input type="submit" name="submit" value="Add Customer" class="btn btn-primary pull-right">
               </div>
            </div>
            <?php echo form_close( ); ?>
         </div>
         <!-- /.box-body -->
      </div>
   </section>
</div>

<script>
function readURL(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#blah').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]); // convert to base64 string
  }
}

$("#imgInp").change(function() {
  readURL(this);
});
</script>













