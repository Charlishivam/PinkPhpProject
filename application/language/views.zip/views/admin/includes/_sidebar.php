<?php 
   $cur_tab = $this->uri->segment(2)==''?'dashboard': $this->uri->segment(2);  
   ?> 
<div class="aside aside-left aside-fixed d-flex flex-column flex-row-auto" id="kt_aside">
   <!--begin::Brand-->
   <div class="brand flex-column-auto" id="kt_brand" kt-hidden-height="65" style="">
      <!--begin::Logo-->
      <a href="index.html" class="brand-logo">
         <!--<img alt="Logo" src="<?= base_url() ?>assets/media/logos/logo-light.png">-->
         <h6>SMS</h6>
      </a>
      <!--end::Logo-->
      <!--begin::Toggle-->
      <button class="brand-toggle btn btn-sm px-0" id="kt_aside_toggle">
         <span class="svg-icon svg-icon svg-icon-xl">
            <!--begin::Svg Icon | path:assets/media/svg/icons/Navigation/Angle-double-left.svg-->
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
               <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                  <polygon points="0 0 24 0 24 24 0 24"></polygon>
                  <path d="M5.29288961,6.70710318 C4.90236532,6.31657888 4.90236532,5.68341391 5.29288961,5.29288961 C5.68341391,4.90236532 6.31657888,4.90236532 6.70710318,5.29288961 L12.7071032,11.2928896 C13.0856821,11.6714686 13.0989277,12.281055 12.7371505,12.675721 L7.23715054,18.675721 C6.86395813,19.08284 6.23139076,19.1103429 5.82427177,18.7371505 C5.41715278,18.3639581 5.38964985,17.7313908 5.76284226,17.3242718 L10.6158586,12.0300721 L5.29288961,6.70710318 Z" fill="#000000" fill-rule="nonzero" transform="translate(8.999997, 11.999999) scale(-1, 1) translate(-8.999997, -11.999999)"></path>
                  <path d="M10.7071009,15.7071068 C10.3165766,16.0976311 9.68341162,16.0976311 9.29288733,15.7071068 C8.90236304,15.3165825 8.90236304,14.6834175 9.29288733,14.2928932 L15.2928873,8.29289322 C15.6714663,7.91431428 16.2810527,7.90106866 16.6757187,8.26284586 L22.6757187,13.7628459 C23.0828377,14.1360383 23.1103407,14.7686056 22.7371482,15.1757246 C22.3639558,15.5828436 21.7313885,15.6103465 21.3242695,15.2371541 L16.0300699,10.3841378 L10.7071009,15.7071068 Z" fill="#000000" fill-rule="nonzero" opacity="0.3" transform="translate(15.999997, 11.999999) scale(-1, 1) rotate(-270.000000) translate(-15.999997, -11.999999)"></path>
               </g>
            </svg>
            <!--end::Svg Icon-->
         </span>
      </button>
      <!--end::Toolbar-->
   </div>
   <!--end::Brand-->
   <!--begin::Aside Menu-->
   <div class="aside-menu-wrapper flex-column-fluid" id="kt_aside_menu_wrapper">
      <!--begin::Menu Container-->
      <div id="kt_aside_menu" class="aside-menu my-4 scroll ps ps--active-y" data-menu-vertical="1" data-menu-scroll="1" data-menu-dropdown-timeout="500" style="height: 59px; overflow: hidden;">
         <!--begin::Menu Nav-->
         <ul class="menu-nav">
            <li class="menu-item menu-item-active" aria-haspopup="true">
               <a href="<?= base_url('admin/dashboard'); ?>" class="menu-link">
                  <span class="svg-icon menu-icon">
                     <i class="flaticon-graph text-light"></i>
                  </span>
                  <span class="menu-text">Dashboard</span>
               </a>
            </li>
            <?php if($this->rbac->check_module_permission('admin')): ?>
            <li class="menu-item menu-item-submenu" aria-haspopup="true" data-menu-toggle="hover">
               <a href="javascript:;" class="menu-link menu-toggle">
                  <span class="svg-icon menu-icon">
                    <i class="flaticon-squares text-light"></i>
                  </span>
                  <span class="menu-text">Master</span>
                  <i class="menu-arrow"></i>
               </a>
               <div class="menu-submenu">
                  <i class="menu-arrow"></i>
                  <ul class="menu-subnav">
                     <li class="menu-item menu-item-submenu" aria-haspopup="true" data-menu-toggle="hover">
                        <a href="javascript:;" class="menu-link menu-toggle">
                        <i class="menu-bullet menu-bullet-line">
                        <span></span>
                        </i>
                        <span class="menu-text">Admin</span>
                        <i class="menu-arrow"></i>
                        </a>
                        <div class="menu-submenu">
                           <i class="menu-arrow"></i>
                           <ul class="menu-subnav">
                              <li class="menu-item" aria-haspopup="true">
                                 <a href="<?= base_url('admin/admin'); ?>" class="menu-link">
                                 <i class="menu-bullet menu-bullet-dot">
                                 <span></span>
                                 </i>
                                 <span class="menu-text">Admin List</span>
                                 </a>
                              </li>
                              <li class="menu-item" aria-haspopup="true">
                                 <a href="<?= base_url('admin/admin/add'); ?>" class="menu-link">
                                 <i class="menu-bullet menu-bullet-dot">
                                 <span></span>
                                 </i>
                                 <span class="menu-text">Add New Admin</span>
                                 </a>
                              </li>
                              <li class="menu-item" aria-haspopup="true">
                                 <a href="<?= base_url('admin/profile'); ?>" class="menu-link">
                                 <i class="menu-bullet menu-bullet-dot">
                                 <span></span>
                                 </i>
                                 <span class="menu-text">Admin Profile</span>
                                 </a>
                              </li>
                           </ul>
                        </div>
                     </li>

                     <li class="menu-item menu-item-submenu" aria-haspopup="true" data-menu-toggle="hover">
                        <a href="javascript:;" class="menu-link menu-toggle">
                        <i class="menu-bullet menu-bullet-line">
                        <span></span>
                        </i>
                        <span class="menu-text">Roles</span>
                        <i class="menu-arrow"></i>
                        </a>
                        <div class="menu-submenu">
                           <i class="menu-arrow"></i>
                           <ul class="menu-subnav">
                              <li class="menu-item" aria-haspopup="true">
                                 <a href="<?= base_url('admin/admin_roles/module'); ?>" class="menu-link">
                                 <i class="menu-bullet menu-bullet-dot">
                                 <span></span>
                                 </i>
                                 <span class="menu-text">Module Setting</span>
                                 </a>
                              </li>
                              <li class="menu-item" aria-haspopup="true">
                                 <a href="<?= base_url('admin/admin_roles'); ?>" class="menu-link">
                                 <i class="menu-bullet menu-bullet-dot">
                                 <span></span>
                                 </i>
                                 <span class="menu-text">Role & Permission</span>
                                 </a>
                              </li>
                           </ul>
                        </div>
                     </li>
                     <li class="menu-item menu-item-submenu" aria-haspopup="true" data-menu-toggle="hover">
                        <a href="<?= base_url('admin/general_settings'); ?>" class="menu-link menu-toggle">
                        <i class="menu-bullet menu-bullet-line">
                        <span></span>
                        </i>
                        <span class="menu-text">Settings</span>
                        </a>
                     </li>
                  </ul>
               </div>
            </li>
            <li class="menu-item menu-item-submenu" aria-haspopup="true" data-menu-toggle="hover">
               <a href="javascript:;" class="menu-link menu-toggle">
                  <span class="svg-icon menu-icon">
                    <i class="flaticon-map text-light"></i>
                  </span>
                  <span class="menu-text">Category</span>
                  <i class="menu-arrow"></i>
               </a>
               <div class="menu-submenu">
                  <i class="menu-arrow"></i>
                  <ul class="menu-subnav">
                     <li class="menu-item" aria-haspopup="true">
                        <a href="<?= base_url('admin/category'); ?>" class="menu-link">
                        <i class="menu-bullet menu-bullet-dot">
                        <span></span>
                        </i>
                        <span class="menu-text">Greetings Category</span>
                        </a>
                     </li>
                     <li class="menu-item" aria-haspopup="true">
                        <a href="<?= base_url('admin/subcategory'); ?>" class="menu-link">
                        <i class="menu-bullet menu-bullet-dot">
                        <span></span>
                        </i>
                        <span class="menu-text">Sub Category</span>
                        </a>
                     </li>

                     <li class="menu-item" aria-haspopup="true">
                        <a href="<?= base_url('admin/subsubcategory'); ?>" class="menu-link">
                        <i class="menu-bullet menu-bullet-dot">
                        <span></span>
                        </i>
                        <span class="menu-text">Greetings</span>
                        </a>
                     </li>
                  </ul>
               </div>
            </li>
            <li class="menu-item" aria-haspopup="true">
               <a href="<?= base_url('admin/customer'); ?>" class="menu-link">
                  <span class="svg-icon menu-icon">
                    <i class="flaticon2-avatar text-light"></i>
                  </span>
                  <span class="menu-text">Customer</span>
               </a>
            </li>
            <li class="menu-item" aria-haspopup="true">
               <a href="<?= base_url('admin/slider'); ?>" class="menu-link">
                  <span class="svg-icon menu-icon">
                     <i class="flaticon2-photograph text-light"></i>
                  </span>
                  <span class="menu-text">Slider</span>
               </a>
            </li>
            <li class="menu-item" aria-haspopup="true">
               <a href="<?= base_url('admin/setting'); ?>" class="menu-link">
                  <span class="svg-icon menu-icon">
                     <i class="flaticon-cogwheel-2 text-light"></i>
                  </span>
                  <span class="menu-text">Setting</span>
               </a>
            </li>
            <li class="menu-item menu-item-submenu" aria-haspopup="true" data-menu-toggle="hover">
               <a href="javascript:;" class="menu-link menu-toggle">
                  <span class="svg-icon menu-icon">
                    <i class="flaticon2-website text-light"></i>
                  </span>
                  <span class="menu-text">Web Links</span>
                  <i class="menu-arrow"></i>
               </a>
               <div class="menu-submenu">
                  <i class="menu-arrow"></i>
                  <ul class="menu-subnav">
                     <li class="menu-item" aria-haspopup="true">
                        <a href="<?= base_url('admin/weblinkcategory'); ?>" class="menu-link">
                        <i class="menu-bullet menu-bullet-dot">
                        <span></span>
                        </i>
                        <span class="menu-text">WebLink Category</span>
                        </a>
                     </li>
                     <li class="menu-item" aria-haspopup="true">
                        <a href="<?= base_url('admin/weblink/template'); ?>" class="menu-link">
                        <i class="menu-bullet menu-bullet-dot">
                        <span></span>
                        </i>
                        <span class="menu-text">WebLink Template</span>
                        </a>
                     </li>
                     <li class="menu-item" aria-haspopup="true">
                        <a href="<?= base_url('admin/weblink'); ?>" class="menu-link">
                        <i class="menu-bullet menu-bullet-dot">
                        <span></span>
                        </i>
                        <span class="menu-text">Web Links</span>
                        </a>
                     </li>
                  </ul>
               </div>
            </li>
            <!--<li class="menu-item" aria-haspopup="true">
               <a href="<?= base_url('admin/adscampaign'); ?>" class="menu-link">
                  <span class="svg-icon menu-icon">
                     <i class="flaticon2-rocket-1 text-light"></i>
                  </span>
                  <span class="menu-text">Ads Campaign</span>
               </a>
            </li>-->
            <?php endif; ?>
         </ul>
         <!--end::Menu Nav-->
         <div class="ps__rail-x" style="left: 0px; bottom: 0px;">
            <div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div>
         </div>
         <div class="ps__rail-y" style="top: 0px; height: 59px; right: 4px;">
            <div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 40px;"></div>
         </div>
      </div>
      <!--end::Menu Container-->
   </div>
   <!--end::Aside Menu-->
</div>